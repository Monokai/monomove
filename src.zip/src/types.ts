export type EasingFunction = (t: number) => number;

export type EasingType = string | EasingFunction;

export interface TweenableObject {
	[key: string]: number;
}

export type UpdateCallback<T> = (values: T) => void;

export interface ITween {
	start(): Promise<void>;
	stop(): void;
	update(deltaTime: number): boolean; // returns false if finished
}

export interface SmoothScrollCallbackData {
	item: HTMLElement;
	factor: number; // 0 to 1 based on viewport position
	rawFactor: number; // Unclamped factor
	box: DOMRect;
}

export type SmoothScrollCallback = (data: SmoothScrollCallbackData) => void;